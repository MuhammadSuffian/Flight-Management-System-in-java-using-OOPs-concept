/*
 * Name-->M.Suffian Tafoor
 * Reg No.-->138
 * Section-->BSSE2C
 */

/**
 *
 * @author Waris
 */
public class Variables extends javax.swing.JFrame {
    private String Uname;
    private String Passcode;
    private String Fname;
    private String contact;
    private String CNIC;
    private String Dateofbirth;
    private String Destination;
    private String apparture;

    public void setDestination(String Destination) {
        this.Destination = Destination;
    }

    public void setApparture(String apparture) {
        this.apparture = apparture;
    }
    

    public void setUname(String Uname) {
        this.Uname = Uname;
    }

    public void setPasscode(String Passcode) {
        this.Passcode = Passcode;
    }

    public String getUname() {
        return Uname;
    }

    public String getPasscode() {
        return Passcode;
    }

    public void setFname(String Fname) {
        this.Fname = Fname;
    }

    public void setContact(String contact) {
        this.contact = contact;
    }

    public void setCNIC(String CNIC) {
        this.CNIC = CNIC;
    }

    public void setDateofbirth(String Dateofbirth) {
        this.Dateofbirth = Dateofbirth;
    }

    public String getFname() {
        return Fname;
    }

    public String getContact() {
        return contact;
    }

    public String getCNIC() {
        return CNIC;
    }

    public String getDateofbirth() {
        return Dateofbirth;
    }

    public String getDestination() {
        return Destination;
    }

    public String getApparture() {
        return apparture;
    }
    
    
    
}
